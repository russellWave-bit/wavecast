package com.breadwinner.wavecast

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import androidx.core.content.ContextCompat
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.Image
import android.media.MediaRecorder
import android.view.Surface
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream

/** Grabs the screen, turns it into pictures, and keeps the web server (and optional hotspot) alive. */
class CastService : Service() {
    private var server: CastServer? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var cpuLock: PowerManager.WakeLock? = null
    private var awakeLock: PowerManager.WakeLock? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var curW = 0
    private var curH = 0
    private var lastEnc = 0L
    private var count = 0
    @Volatile private var audioRec: AudioRecord? = null
    private var audioThread: Thread? = null

    // camera (round 3)
    private var camDev: CameraDevice? = null
    private var camSession: CameraCaptureSession? = null
    private var camReader: ImageReader? = null
    private var camThread: HandlerThread? = null
    private var camBuilder: CaptureRequest.Builder? = null
    private var camSensor = 90
    private var camFrontNow = false
    private var camFpsGap = 66L
    private var camLastEnc = 0L

    // microphone (round 3)
    @Volatile private var micRun = false
    private var micThread: Thread? = null

    companion object {
        const val STOP = "wavecast.stop"
        const val CH = "cast"
        @Volatile var inst: CastService? = null
    }

    override fun onCreate() {
        super.onCreate()
        inst = this
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Casting", NotificationManager.IMPORTANCE_LOW))
        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (Build.VERSION.SDK_INT >= 30) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
        }
        try {
            startForeground(1, notif(), types)
        } catch (e: Exception) {
            Hub.logErr("Camera and microphone could not be added: " + (e.message ?: ""))
            startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        }

        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        val code = i?.getIntExtra("code", 0) ?: 0
        if (data == null || code == 0) {
            Hub.hotspotMsg = "Screen capture was not allowed."
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        startServer()
        if (server == null) {
            Hub.hotspotMsg = "Could not start the casting server."
            stopSelf()
            return START_NOT_STICKY
        }
        val pm = getSystemService(PowerManager::class.java)
        cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wavecast:cpu").apply { acquire() }
        if (Hub.stayAwake) {
            @Suppress("DEPRECATION")
            awakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ON_AFTER_RELEASE, "wavecast:awake").apply { acquire() }
        }
        thread = HandlerThread("wavecast-capture").also { it.start() }
        handler = Handler(thread!!.looper)

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val mp = mpm.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    Hub.logErr("Screen capture was stopped by Android")
                    stopSelf()
                }
            }, handler)
            projection = mp
            Frames.reset()
            Hub.newPin()
            buildDisplay()
            startAudio(mp)
            startMicLoop()
            handler?.postDelayed(tick, 1000)
            Hub.running = true
            Hub.mode = i?.getIntExtra("mode", 1) ?: 1
            if (Hub.mode == 1 && reservation == null) startHotspot()
        } catch (e: Exception) {
            Hub.logErr("Could not start capture: " + (e.message ?: e.javaClass.simpleName))
            Hub.hotspotMsg = "Could not start screen capture."
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            Hub.sentFps = count
            count = 0
            Hub.droppedShown = Hub.dropped
            Hub.audioListeners = AudioPipe.count
            Hub.recount()
            if (Hub.camOn && (!Hub.camAllowed || System.currentTimeMillis() - Hub.lastCamPoll > 9000L)) camStop()
            if (!Hub.controlOn) WaveControl.inst?.releaseAll()
            try {
                val (w, h) = targetSize()
                if (display != null && (w != curW || h != curH)) buildDisplay()
            } catch (e: Exception) {
                Hub.logErr("Resize failed: " + (e.message ?: ""))
            }
            handler?.postDelayed(this, 1000)
        }
    }

    private fun targetSize(): Pair<Int, Int> {
        val m = DisplayMetrics()
        val wm = getSystemService(WindowManager::class.java)
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        val s = Hub.scalePct.coerceIn(20, 100) / 100f
        val w = ((m.widthPixels * s).toInt() / 2 * 2).coerceAtLeast(160)
        val h = ((m.heightPixels * s).toInt() / 2 * 2).coerceAtLeast(160)
        return w to h
    }

    private fun buildDisplay() {
        val mp = projection ?: return
        val (w, h) = targetSize()
        val old = reader
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd -> onImage(rd) }, handler)
        val dpi = resources.displayMetrics.densityDpi
        val d = display
        if (d == null) {
            display = mp.createVirtualDisplay(
                "WaveCast", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
            )
        } else {
            d.resize(w, h, dpi)
            d.surface = r.surface
        }
        reader = r
        curW = w
        curH = h
        try { old?.close() } catch (e: Exception) { }
    }

    private fun onImage(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastEnc < 1000L / Hub.fps.coerceIn(1, 60)) return
            lastEnc = now
            val plane = img.planes[0]
            val ps = plane.pixelStride
            val rowW = plane.rowStride / ps
            val bmp = Bitmap.createBitmap(rowW, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(plane.buffer)
            val crop = if (rowW != img.width) Bitmap.createBitmap(bmp, 0, 0, img.width, img.height) else bmp
            val out = ByteArrayOutputStream(48 * 1024)
            crop.compress(Bitmap.CompressFormat.JPEG, Hub.quality.coerceIn(10, 100), out)
            if (crop !== bmp) crop.recycle()
            bmp.recycle()
            val bytes = out.toByteArray()
            Frames.put(bytes)
            count++
            Hub.encodeMs = (SystemClock.elapsedRealtime() - now).toInt()
            Hub.lastKb = bytes.size / 1024
            Hub.frameW = img.width
            Hub.frameH = img.height
        } catch (e: Exception) {
            Hub.logErr("Picture failed: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            img.close()
        }
    }

    /** Copies the sound the phone is playing, so the PC page can play it too. */
    private fun startAudio(mp: MediaProjection) {
        Hub.audioMsg = ""
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Hub.audioMsg = "Sound needs the Microphone permission. Android uses it for sound capture too. Allow it, then start again."
            return
        }
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(48000, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minBuf, 3840 * 8))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                Hub.audioMsg = "This phone could not start sound capture."
                return
            }
            rec.startRecording()
            audioRec = rec
            val t = Thread({
                val buf = ByteArray(3840)
                while (audioRec === rec) {
                    val r = try { rec.read(buf, 0, buf.size) } catch (e: Exception) { -1 }
                    if (r < 0) break
                    if (r == 0) {
                        try { Thread.sleep(5) } catch (e: InterruptedException) { }
                        continue
                    }
                    if (Hub.soundOn && AudioPipe.count > 0) AudioPipe.push(buf.copyOf(r))
                }
            }, "wavecast-audio")
            audioThread = t
            t.start()
        } catch (e: Exception) {
            Hub.audioMsg = "Sound capture failed: " + (e.message ?: e.javaClass.simpleName)
            Hub.logErr(Hub.audioMsg)
        }
    }

    // ---------- camera ----------

    /** Opens the phone camera for the PC page. Returns "" when it is starting, or a short reason code. */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun camStart(front: Boolean, q: Int): String {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            Hub.camMsg = "Camera needs its permission. Allow it, then start casting again."
            return "perm"
        }
        camStop()
        Hub.camMsg = ""
        try {
            val cm = getSystemService(CameraManager::class.java)
            val want = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
            var id: String? = null
            for (cid in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(cid)
                if (c.get(CameraCharacteristics.LENS_FACING) == want) {
                    id = cid
                    break
                }
            }
            if (id == null) {
                Hub.camMsg = "This phone has no " + (if (front) "front" else "back") + " camera."
                return "none"
            }
            val ch = cm.getCameraCharacteristics(id)
            camSensor = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            camFrontNow = front
            Hub.camFront = front
            Hub.camHasFlash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            if (!Hub.camHasFlash || front) Hub.camTorch = false
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(ImageFormat.YUV_420_888)
            if (sizes == null || sizes.isEmpty()) {
                Hub.camMsg = "The camera gave no picture sizes."
                return "none"
            }
            val target = when (q) { 0 -> 640; 2 -> 1920; else -> 1280 }
            var pick = sizes.filter { maxOf(it.width, it.height) <= target }.maxByOrNull { it.width * it.height }
            if (pick == null) pick = sizes.minByOrNull { it.width * it.height }
            val size = pick ?: sizes[0]
            camFpsGap = when (q) { 0 -> 50L; 2 -> 100L; else -> 66L }
            val t = HandlerThread("wavecast-cam")
            t.start()
            camThread = t
            val h = Handler(t.looper)
            val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.YUV_420_888, 2)
            reader.setOnImageAvailableListener({ rd -> onCamImage(rd) }, h)
            camReader = reader
            CamFrames.reset()
            Hub.lastCamPoll = System.currentTimeMillis()
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    camDev = d
                    try {
                        val rb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                        rb.addTarget(reader.surface)
                        rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        camBuilder = rb
                        applyTorchTo(rb)
                        d.createCaptureSession(listOf(reader.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(sess: CameraCaptureSession) {
                                camSession = sess
                                try {
                                    sess.setRepeatingRequest(rb.build(), null, h)
                                    Hub.camOn = true
                                } catch (e: Exception) {
                                    Hub.camMsg = "Camera would not start: " + (e.message ?: "")
                                    camStop()
                                }
                            }

                            override fun onConfigureFailed(sess: CameraCaptureSession) {
                                Hub.camMsg = "The camera could not be set up."
                                camStop()
                            }
                        }, h)
                    } catch (e: Exception) {
                        Hub.camMsg = "Camera would not start: " + (e.message ?: "")
                        camStop()
                    }
                }

                override fun onDisconnected(d: CameraDevice) {
                    Hub.camMsg = "The camera was taken by another app."
                    camStop()
                }

                override fun onError(d: CameraDevice, err: Int) {
                    Hub.camMsg = "Camera error $err"
                    camStop()
                }
            }, h)
            return ""
        } catch (e: Exception) {
            Hub.camMsg = "Camera would not start: " + (e.message ?: e.javaClass.simpleName)
            Hub.logErr(Hub.camMsg)
            camStop()
            return "fail"
        }
    }

    @Synchronized
    fun camStop() {
        Hub.camOn = false
        try { camSession?.close() } catch (e: Exception) { }
        camSession = null
        try { camDev?.close() } catch (e: Exception) { }
        camDev = null
        try { camReader?.close() } catch (e: Exception) { }
        camReader = null
        camBuilder = null
        try { camThread?.quitSafely() } catch (e: Exception) { }
        camThread = null
        Hub.camTorch = false
        CamFrames.reset()
    }

    private fun applyTorchTo(rb: CaptureRequest.Builder) {
        rb.set(CaptureRequest.FLASH_MODE, if (Hub.camTorch && Hub.camHasFlash) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)
    }

    @Synchronized
    fun camApplyTorch() {
        val rb = camBuilder ?: return
        val sess = camSession ?: return
        try {
            applyTorchTo(rb)
            sess.setRepeatingRequest(rb.build(), null, camThread?.let { Handler(it.looper) })
        } catch (e: Exception) {
            Hub.logErr("Torch: " + (e.message ?: ""))
        }
    }

    private fun nv21(img: Image): ByteArray {
        val w = img.width
        val h = img.height
        val out = ByteArray(w * h * 3 / 2)
        val yP = img.planes[0]
        val uP = img.planes[1]
        val vP = img.planes[2]
        val yb = yP.buffer
        val ub = uP.buffer
        val vb = vP.buffer
        var pos = 0
        for (r in 0 until h) {
            yb.position(r * yP.rowStride)
            yb.get(out, pos, w)
            pos += w
        }
        val cw = w / 2
        val chh = h / 2
        for (r in 0 until chh) {
            for (c in 0 until cw) {
                out[pos++] = vb.get(r * vP.rowStride + c * vP.pixelStride)
                out[pos++] = ub.get(r * uP.rowStride + c * uP.pixelStride)
            }
        }
        return out
    }

    private fun onCamImage(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - camLastEnc < camFpsGap) return
            camLastEnc = now
            val data = nv21(img)
            val yuv = YuvImage(data, ImageFormat.NV21, img.width, img.height, null)
            val out = ByteArrayOutputStream(64 * 1024)
            yuv.compressToJpeg(Rect(0, 0, img.width, img.height), 72, out)
            @Suppress("DEPRECATION")
            val rot = when (getSystemService(WindowManager::class.java).defaultDisplay.rotation) {
                Surface.ROTATION_90 -> 90
                Surface.ROTATION_180 -> 180
                Surface.ROTATION_270 -> 270
                else -> 0
            }
            Hub.camRot = if (camFrontNow) (camSensor + rot) % 360 else (camSensor - rot + 360) % 360
            Hub.camMirror = camFrontNow
            CamFrames.put(out.toByteArray())
        } catch (e: Exception) {
            Hub.logErr("Camera picture failed: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            img.close()
        }
    }

    // ---------- microphone ----------

    /** Listens to the microphone only while a PC page is listening and the switch is on. */
    private fun startMicLoop() {
        if (micRun) return
        micRun = true
        val t = Thread({
            var rec: AudioRecord? = null
            val buf = ByteArray(1920)
            while (micRun) {
                val want = Hub.micAllowed && MicPipe.count > 0 &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (!want) {
                    if (rec != null) {
                        try { rec.stop() } catch (e: Exception) { }
                        try { rec.release() } catch (e: Exception) { }
                        rec = null
                        Hub.micLive = false
                    }
                    try { Thread.sleep(200) } catch (e: InterruptedException) { }
                    continue
                }
                if (rec == null) {
                    try {
                        val minBuf = AudioRecord.getMinBufferSize(48000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                        @SuppressLint("MissingPermission")
                        val r = AudioRecord(MediaRecorder.AudioSource.MIC, 48000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 1920 * 6))
                        if (r.state != AudioRecord.STATE_INITIALIZED) {
                            r.release()
                            Hub.logErr("The microphone could not start (another app may be using it).")
                            try { Thread.sleep(1500) } catch (e: InterruptedException) { }
                            continue
                        }
                        r.startRecording()
                        rec = r
                        Hub.micLive = true
                    } catch (e: Exception) {
                        Hub.logErr("Microphone: " + (e.message ?: e.javaClass.simpleName))
                        try { Thread.sleep(1500) } catch (x: InterruptedException) { }
                        continue
                    }
                }
                val n = try { rec!!.read(buf, 0, buf.size) } catch (e: Exception) { -1 }
                if (n < 0) {
                    try { rec?.release() } catch (e: Exception) { }
                    rec = null
                    Hub.micLive = false
                    try { Thread.sleep(500) } catch (e: InterruptedException) { }
                    continue
                }
                if (n > 0) MicPipe.push(buf.copyOf(n))
            }
            try { rec?.stop() } catch (e: Exception) { }
            try { rec?.release() } catch (e: Exception) { }
            Hub.micLive = false
        }, "wavecast-mic")
        micThread = t
        t.start()
    }

    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CastService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveCast is casting")
            .setContentText("Open the address on your PC")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop", stop).build())
            .build()
    }

    private fun startServer() {
        for (p in 8080..8090) {
            try {
                val s = CastServer(p, applicationContext)
                s.start()
                server = s
                Hub.port = p
                return
            } catch (e: Exception) {
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun startHotspot() {
        Hub.hotspotMsg = "Starting the hotspot..."
        val wm = applicationContext.getSystemService(WifiManager::class.java)
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        Hub.ssid = c.ssid ?: ""
                        Hub.pass = c.passphrase ?: ""
                    } else {
                        val c = r.wifiConfiguration
                        Hub.ssid = (c?.SSID ?: "").trim('"')
                        Hub.pass = c?.preSharedKey ?: ""
                    }
                    Hub.hotspotMsg = ""
                }

                override fun onStopped() {
                    Hub.ssid = ""
                    Hub.pass = ""
                    Hub.hotspotMsg = "The hotspot stopped."
                }

                override fun onFailed(reason: Int) {
                    Hub.hotspotMsg = when (reason) {
                        ERROR_NO_CHANNEL -> "No Wi-Fi channel is free right now. Try again."
                        ERROR_INCOMPATIBLE_MODE -> "Turn off your normal hotspot first, then try again."
                        ERROR_TETHERING_DISALLOWED -> "This phone does not allow apps to start a hotspot."
                        else -> "The hotspot could not start. Make sure Location is switched on."
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            Hub.hotspotMsg = "Allow the permission and switch Location on, then try again."
        } catch (e: Exception) {
            Hub.hotspotMsg = "The hotspot could not start on this phone."
        }
    }

    override fun onDestroy() {
        inst = null
        micRun = false
        micThread = null
        camStop()
        Finder.stop(applicationContext)
        WaveControl.inst?.releaseAll()
        handler?.removeCallbacksAndMessages(null)
        val rec = audioRec
        audioRec = null
        try { rec?.stop() } catch (e: Exception) { }
        try { rec?.release() } catch (e: Exception) { }
        audioThread = null
        try { display?.release() } catch (e: Exception) { }
        display = null
        try { reader?.close() } catch (e: Exception) { }
        reader = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        try { reservation?.close() } catch (e: Exception) { }
        reservation = null
        try { server?.stop() } catch (e: Exception) { }
        server = null
        try { thread?.quitSafely() } catch (e: Exception) { }
        thread = null
        try { cpuLock?.release() } catch (e: Exception) { }
        try { awakeLock?.release() } catch (e: Exception) { }
        cpuLock = null
        awakeLock = null
        Frames.reset()
        Hub.running = false
        Hub.ssid = ""
        Hub.pass = ""
        Hub.sentFps = 0
        Hub.audioListeners = 0
        Hub.pin = ""
        Hub.clearSeen()
        super.onDestroy()
    }
}
