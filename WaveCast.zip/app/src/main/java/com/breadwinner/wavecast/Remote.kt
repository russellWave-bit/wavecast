package com.breadwinner.wavecast

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL


// The remote control side of WaveCast: see and control another phone that is casting.
private val RShadow = Color(0x331E2D50)

@Composable
fun RT(
    text: String, size: Int = 13, color: Color = Ink, weight: FontWeight = FontWeight.SemiBold,
    modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE
) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

fun Modifier.rGlassDot(): Modifier = this
    .shadow(6.dp, CircleShape, ambientColor = RShadow, spotColor = RShadow)
    .clip(CircleShape)
    .background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFDDE4F0))))
    .border(1.dp, Color.White, CircleShape)

/** The Remote tab: scan the other phone's code, or find it. */
@Composable
fun RemoteTab(go: (RTarget) -> Unit) {
    val ctx = LocalContext.current
    RemoteHome(RNet.last(ctx)) { RNet.save(ctx, it); go(it) }
}

// ───────────────────────── HOME ─────────────────────────

@Composable
fun RScanDisc(onClick: () -> Unit) {
    Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val r = 88.dp.toPx()
            for (k in 0..5) {
                drawCircle(RShadow.copy(alpha = 0.05f), r + (3 + k * 3).dp.toPx(), Offset(c.x, c.y + (8 + k).dp.toPx()))
            }
            drawCircle(
                Brush.sweepGradient(
                    listOf(
                        Color(0xFFFAFBFD), Color(0xFFB7BFCB), Color(0xFFF1F4F8), Color(0xFF98A2B0),
                        Color(0xFFFAFBFD), Color(0xFFC3CAD5), Color(0xFFFFFFFF), Color(0xFFA6AFBC), Color(0xFFFAFBFD)
                    ), c
                ), r, c
            )
            drawCircle(Color.White.copy(alpha = 0.9f), r, c, style = Stroke(2.dp.toPx()))
            drawCircle(
                Brush.radialGradient(listOf(Color(0x55FFFFFF), Color(0x00FFFFFF), Color(0x22000000)), Offset(c.x - r * 0.3f, c.y - r * 0.45f), r * 1.3f),
                r - 3.dp.toPx(), c
            )
            drawOval(
                Brush.verticalGradient(listOf(Color(0xDDFFFFFF), Color(0x00FFFFFF)), c.y - r * 0.92f, c.y - r * 0.1f),
                Offset(c.x - r * 0.62f, c.y - r * 0.92f), Size(r * 1.24f, r * 0.8f)
            )
            // scan corners
            val ink = Color(0xFF2A313B)
            val s = 54.dp.toPx()
            val l = 16.dp.toPx()
            val w = 5.dp.toPx()
            val x0 = c.x - s / 2
            val y0 = c.y - s / 2
            val x1 = c.x + s / 2
            val y1 = c.y + s / 2
            fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                drawLine(ink, Offset(x, y), Offset(x + dx * l, y), w, StrokeCap.Round)
                drawLine(ink, Offset(x, y), Offset(x, y + dy * l), w, StrokeCap.Round)
            }
            corner(x0, y0, 1f, 1f)
            corner(x1, y0, -1f, 1f)
            corner(x0, y1, 1f, -1f)
            corner(x1, y1, -1f, -1f)
            drawCircle(Blue, 5.dp.toPx(), c)
        }
        Box(Modifier.size(176.dp).clip(CircleShape).clickable { onClick() })
    }
}

@Composable
fun RemoteHome(last: RTarget?, go: (RTarget) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var finding by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<List<RTarget>>(emptyList()) }
    var typing by remember { mutableStateOf(false) }
    var askPin by remember { mutableStateOf<RTarget?>(null) }

    val scan: () -> Unit = {
        msg = ""
        try {
            val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(ctx, opts).startScan()
                .addOnSuccessListener { b ->
                    val t = RNet.parseTarget(b.rawValue ?: "")
                    if (t == null) msg = "That code is not from WaveCast."
                    else if (t.pin.isEmpty()) askPin = t
                    else go(t)
                }
                .addOnFailureListener { msg = "The scanner could not open. It needs Google Play services." }
        } catch (e: Exception) {
            msg = "The scanner could not open. It needs Google Play services."
        }
    }

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(28.dp))
        RT("WaveCast Remote", 26, weight = FontWeight.Bold)
        RT("Control another phone", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(30.dp))
        RScanDisc(scan)
        Spacer(Modifier.height(10.dp))
        RT("Scan the code on the other phone", 16, weight = FontWeight.Bold)
        RT("Open WaveCast there and start casting", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Pill(if (finding) "Looking..." else "Find phone", false) {
                if (!finding) {
                    finding = true
                    found = emptyList()
                    msg = ""
                    scope.launch {
                        val r = RNet.find()
                        finding = false
                        found = r
                        if (r.isEmpty()) msg = "No phone found. Start casting in WaveCast and join the same Wi-Fi."
                    }
                }
            }
            Pill("Type address", false) { typing = true }
        }
        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            RT(msg, 12, Danger, FontWeight.Medium)
        }
        if (last != null) {
            Spacer(Modifier.height(20.dp))
            Card(Modifier.fillMaxWidth()) {
                RT("Last phone", 12, Muted)
                RT(last.addr, 20, weight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Pill("Reconnect") { go(last) }
            }
        }
        for (f in found) {
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth()) {
                RT("Found a WaveCast phone", 12, Muted)
                RT(f.addr, 20, weight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Pill("Connect") { askPin = f }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (typing) {
        var addr by remember { mutableStateOf("") }
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { typing = false },
            title = { Text("Type the address") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(addr, { addr = it }, singleLine = true, label = { Text("Address, like 192.168.1.5:8080") })
                    OutlinedTextField(pin, { pin = it }, singleLine = true, label = { Text("PIN") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = RNet.parseTarget(addr, pin.trim())
                    if (t == null) msg = "That address does not look right." else go(t)
                    typing = false
                }) { Text("Connect") }
            },
            dismissButton = { TextButton(onClick = { typing = false }) { Text("Cancel") } }
        )
    }
    val ap = askPin
    if (ap != null) {
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { askPin = null },
            title = { Text("PIN for " + ap.addr) },
            text = {
                OutlinedTextField(pin, { pin = it }, singleLine = true, label = { Text("The PIN shown in WaveCast") })
            },
            confirmButton = {
                TextButton(onClick = { askPin = null; go(RTarget(ap.host, ap.port, pin.trim())) }) { Text("Connect") }
            },
            dismissButton = { TextButton(onClick = { askPin = null }) { Text("Cancel") } }
        )
    }
}

// ───────────────────────── REMOTE ─────────────────────────

/** Sends finger movements one after another, merging moves so it never falls behind. */
class RTouchSender(private val t: RTarget, private val fail: (String) -> Unit) {
    private class Msg(val id: Int, val k: String, var x: Float, var y: Float)

    private val q = ArrayList<Msg>()
    private var running = false
    private val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO)

    fun send(id: Int, k: String, x: Float, y: Float) {
        synchronized(q) {
            if (k == "move") {
                for (i in q.indices.reversed()) {
                    if (q[i].id == id) {
                        if (q[i].k == "move") {
                            q[i].x = x
                            q[i].y = y
                            return
                        }
                        break
                    }
                }
            }
            q.add(Msg(id, k, x, y))
            if (running) return
            running = true
        }
        scope.launch {
            while (true) {
                var m: Msg? = null
                synchronized(q) {
                    if (q.isEmpty()) {
                        running = false
                    } else {
                        m = q.removeAt(0)
                    }
                }
                val cur = m ?: return@launch
                val r = RNet.ctl(
                    t, "a", "touch", "id", cur.id.toString(), "k", cur.k,
                    "x", String.format(java.util.Locale.US, "%.4f", cur.x), "y", String.format(java.util.Locale.US, "%.4f", cur.y)
                )
                if (!r.first) {
                    synchronized(q) {
                        q.clear()
                        running = false
                    }
                    fail(r.second)
                    return@launch
                }
            }
        }
    }

    fun stop() {
        scope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
    }
}

@Composable
fun RemoteScreen(t: RTarget, onExit: () -> Unit) {
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var bmp by remember { mutableStateOf<ImageBitmap?>(null) }
    var status by remember { mutableStateOf("Connecting...") }
    var live by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var typing by remember { mutableStateOf(false) }
    val bmpRef = rememberUpdatedState(bmp)

    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    BackHandler { onExit() }

    LaunchedEffect(toast) {
        if (toast.isNotEmpty()) {
            delay(3500)
            toast = ""
        }
    }

    val sender = remember(t) { RTouchSender(t) { err -> toast = RNet.words(err) } }
    DisposableEffect(t) {
        onDispose {
            sender.stop()
            Thread { RNet.ctl(t, "a", "release") }.start()
        }
    }

    // pull pictures
    LaunchedEffect(t) {
        withContext(Dispatchers.IO) {
            var seq = -1
            var fails = 0
            var quiet = 0
            while (isActive) {
                try {
                    val c = URL(t.url("/frame?after=$seq&pin=" + RNet.enc(t.pin))).openConnection() as HttpURLConnection
                    c.connectTimeout = 3000
                    c.readTimeout = 8000
                    val code = c.responseCode
                    if (code == 204) {
                        fails = 0
                        quiet++
                        live = true
                        status = if (quiet > 6 && bmp == null) "Waiting for the screen. Tap Start casting on the other phone." else "Live"
                        c.inputStream.close()
                        continue
                    }
                    if (code == 403) {
                        val why = c.errorStream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                        live = false
                        status = if (why == "locked") "Too many tries. Wait 30 seconds." else "Wrong PIN"
                        delay(1500)
                        continue
                    }
                    if (code != 200) throw java.io.IOException("code $code")
                    val bytes = c.inputStream.use { it.readBytes() }
                    c.getHeaderField("X-Seq")?.toIntOrNull()?.let { seq = it }
                    val b = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (b != null) bmp = b.asImageBitmap()
                    fails = 0
                    quiet = 0
                    live = true
                    status = "Live"
                } catch (e: Exception) {
                    fails++
                    if (fails >= 2) {
                        live = false
                        status = "Cannot reach the other phone"
                    }
                    delay(if (fails < 5) 400L else 1200L)
                }
            }
        }
    }

    val act: (Array<String>) -> Unit = { kv ->
        scope.launch(Dispatchers.IO) {
            val r = RNet.ctl(t, *kv)
            if (!r.first) toast = RNet.words(r.second)
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).rGlassDot().clickable { onExit() }, contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(18.dp)) {
                    val w = 2.5.dp.toPx()
                    drawLine(Ink, Offset(size.width * 0.62f, size.height * 0.2f), Offset(size.width * 0.32f, size.height * 0.5f), w, StrokeCap.Round)
                    drawLine(Ink, Offset(size.width * 0.32f, size.height * 0.5f), Offset(size.width * 0.62f, size.height * 0.8f), w, StrokeCap.Round)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                RT(t.addr, 15, weight = FontWeight.Bold, maxLines = 1)
            }
            val chipShape = RoundedCornerShape(20.dp)
            Row(
                Modifier.clip(chipShape).background(if (live && status == "Live") Good else Color(0xCCFFFFFF))
                    .border(1.dp, if (live && status == "Live") Color.Transparent else Hair, chipShape)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val on = live && status == "Live"
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (on) Color.White else Muted))
                Spacer(Modifier.width(6.dp))
                RT(if (on) "LIVE" else "OFF", 11, if (on) Color.White else Muted)
            }
        }

        // the other phone's screen
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b != null) {
                val shape = RoundedCornerShape(14.dp)
                Image(
                    bitmap = b, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().shadow(8.dp, shape, ambientColor = RShadow, spotColor = RShadow).clip(shape)
                )
            } else {
                RT(status, 14, Muted, FontWeight.Medium, modifier = Modifier.padding(24.dp))
            }
            // touch layer: finger positions are sent as fractions of the other phone's screen
            Box(
                Modifier.fillMaxSize().pointerInput(t) {
                    val slots = HashMap<Long, Int>()
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent()
                            val img = bmpRef.value
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            var ox = 0f
                            var oy = 0f
                            var iw = w
                            var ih = h
                            if (img != null) {
                                val sc = minOf(w / img.width, h / img.height)
                                iw = img.width * sc
                                ih = img.height * sc
                                ox = (w - iw) / 2f
                                oy = (h - ih) / 2f
                            }
                            for (c in ev.changes) {
                                val nx = ((c.position.x - ox) / iw).coerceIn(0f, 1f)
                                val ny = ((c.position.y - oy) / ih).coerceIn(0f, 1f)
                                val key = c.id.value
                                if (c.pressed && !c.previousPressed) {
                                    var slot = -1
                                    for (s in 0 until 8) {
                                        if (!slots.containsValue(s)) {
                                            slot = s
                                            break
                                        }
                                    }
                                    if (slot >= 0) {
                                        slots[key] = slot
                                        sender.send(slot, "down", nx, ny)
                                    }
                                } else if (c.pressed) {
                                    val slot = slots[key]
                                    if (slot != null && c.positionChanged()) sender.send(slot, "move", nx, ny)
                                } else if (c.previousPressed) {
                                    val slot = slots.remove(key)
                                    if (slot != null) sender.send(slot, "up", nx, ny)
                                }
                                c.consume()
                            }
                        }
                    }
                }
            )
            if (toast.isNotEmpty()) {
                Box(
                    Modifier.align(Alignment.BottomCenter).padding(12.dp).clip(RoundedCornerShape(14.dp))
                        .background(Color(0xE6FFFFFF)).border(1.dp, Hair, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 10.dp)
                ) { RT(toast, 12, Danger, FontWeight.Medium) }
            }
        }

        // the buttons of the other phone
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp).navigationBarsPadding(),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            RNavBtn(0) { act(arrayOf("a", "back")) }
            RNavBtn(1) { act(arrayOf("a", "home")) }
            RNavBtn(2) { act(arrayOf("a", "recents")) }
            RNavBtn(3) { typing = true }
            Box {
                RNavBtn(4) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    val items = listOf(
                        "Notifications" to arrayOf("a", "notif"),
                        "Quick settings" to arrayOf("a", "quick"),
                        "Screenshot" to arrayOf("a", "shot"),
                        "Lock screen" to arrayOf("a", "lock"),
                        "Power menu" to arrayOf("a", "power"),
                        "Volume up" to arrayOf("a", "vol", "d", "up"),
                        "Volume down" to arrayOf("a", "vol", "d", "down"),
                        "Wake screen" to arrayOf("a", "wake")
                    )
                    for ((label, kv) in items) {
                        DropdownMenuItem(text = { Text(label) }, onClick = { menu = false; act(kv) })
                    }
                    DropdownMenuItem(text = { Text("Disconnect") }, onClick = { menu = false; onExit() })
                }
            }
        }
    }

    if (typing) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { typing = false },
            title = { Text("Type on the other phone") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(text, { text = it }, label = { Text("Tap a text box over there first") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { act(arrayOf("a", "key", "k", "del")) }) { Text("Delete") }
                        TextButton(onClick = { act(arrayOf("a", "key", "k", "enter")) }) { Text("Enter") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (text.isNotEmpty()) act(arrayOf("a", "type", "t", text))
                    typing = false
                }) { Text("Send") }
            },
            dismissButton = { TextButton(onClick = { typing = false }) { Text("Close") } }
        )
    }
}

/** The round glass buttons: 0 back, 1 home, 2 recents, 3 keyboard, 4 more. */
@Composable
fun RNavBtn(kind: Int, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).rGlassDot().clickable { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(22.dp)) {
            val w = 2.4.dp.toPx()
            val s = size.width
            when (kind) {
                0 -> {
                    val p = Path()
                    p.moveTo(s * 0.72f, s * 0.14f)
                    p.lineTo(s * 0.22f, s * 0.5f)
                    p.lineTo(s * 0.72f, s * 0.86f)
                    p.close()
                    drawPath(p, Ink, style = Stroke(w, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                }
                1 -> drawCircle(Ink, s * 0.38f, Offset(s / 2, s / 2), style = Stroke(w))
                2 -> drawRoundRect(Ink, Offset(s * 0.16f, s * 0.16f), Size(s * 0.68f, s * 0.68f), CornerRadius(s * 0.12f), style = Stroke(w))
                3 -> {
                    drawRoundRect(Ink, Offset(s * 0.04f, s * 0.26f), Size(s * 0.92f, s * 0.48f), CornerRadius(s * 0.1f), style = Stroke(w))
                    drawLine(Ink, Offset(s * 0.24f, s * 0.58f), Offset(s * 0.76f, s * 0.58f), w, StrokeCap.Round)
                    drawCircle(Ink, 1.3.dp.toPx(), Offset(s * 0.28f, s * 0.42f))
                    drawCircle(Ink, 1.3.dp.toPx(), Offset(s * 0.5f, s * 0.42f))
                    drawCircle(Ink, 1.3.dp.toPx(), Offset(s * 0.72f, s * 0.42f))
                }
                else -> {
                    for (k in 0..2) drawCircle(Ink, 2.2.dp.toPx(), Offset(s * (0.16f + 0.34f * k), s / 2))
                }
            }
        }
    }
}
