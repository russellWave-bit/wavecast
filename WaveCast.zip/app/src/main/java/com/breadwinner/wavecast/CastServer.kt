package com.breadwinner.wavecast

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException

/** Makes the phone loud so it can be found: alarm sound at full volume and a buzz. */
object Finder {
    private var tone: Ringtone? = null
    private var oldVol = -1
    private val main = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { stop(lastCtx) }
    private var lastCtx: Context? = null

    fun start(ctx: Context) {
        stop(ctx)
        lastCtx = ctx
        try {
            val am = ctx.getSystemService(AudioManager::class.java)
            oldVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (e: Exception) {
            oldVol = -1
        }
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val t = RingtoneManager.getRingtone(ctx, uri)
            t.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) t.isLooping = true
            t.play()
            tone = t
        } catch (e: Exception) {
            Hub.logErr("Could not play the alarm: " + (e.message ?: ""))
        }
        buzz(ctx, longArrayOf(0, 700, 350), 0)
        Hub.ringing = true
        main.removeCallbacks(autoStop)
        main.postDelayed(autoStop, 90_000)
    }

    fun stop(ctx: Context?) {
        main.removeCallbacks(autoStop)
        try { tone?.stop() } catch (e: Exception) { }
        tone = null
        if (ctx != null) {
            try {
                if (oldVol >= 0) ctx.getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, oldVol, 0)
            } catch (e: Exception) { }
            try { ctx.getSystemService(Vibrator::class.java).cancel() } catch (e: Exception) { }
        }
        oldVol = -1
        Hub.ringing = false
    }

    fun buzz(ctx: Context, pattern: LongArray, repeat: Int) {
        try {
            val v = ctx.getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createWaveform(pattern, repeat))
        } catch (e: Exception) {
        }
    }
}

/** The little web server on the phone. The PC just opens its address in a browser. */
class CastServer(port: Int, private val ctx: Context) : NanoHTTPD(port) {
    private var pageCache: String? = null

    override fun serve(session: IHTTPSession): Response {
        Hub.touch(session.remoteIpAddress ?: "?")
        val uri = session.uri
        return try {
            if (Hub.viewLock && (uri == "/frame" || uri == "/audio")) {
                val bad = checkPin(session.parameters["pin"]?.firstOrNull() ?: "")
                if (bad != 0) return text(Status.FORBIDDEN, if (bad == 2) "locked" else "pin")
            }
            when {
                uri == "/" -> page()
                uri == "/frame" -> frame(session)
                uri == "/info" -> json(info())
                uri == "/ping" -> ping()
                uri == "/cfg" -> cfg(session)
                uri == "/clip" -> clip(session)
                uri == "/log" -> log(session)
                uri == "/ctl" -> ctl(session)
                uri == "/audio" -> audio()
                uri == "/cam" -> cam(session)
                uri == "/mic" -> mic(session)
                uri == "/upload" && session.method == Method.POST -> upload(session)
                else -> text(Status.NOT_FOUND, "Not found")
            }
        } catch (e: Exception) {
            Hub.logErr("Server: " + (e.message ?: e.javaClass.simpleName))
            text(Status.INTERNAL_ERROR, "Something went wrong on the phone")
        }
    }

    private fun text(status: Status, msg: String): Response =
        newFixedLengthResponse(status, "text/plain", msg)

    private fun noCache(r: Response): Response {
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun json(o: JSONObject): Response =
        noCache(newFixedLengthResponse(Status.OK, "application/json", o.toString()))

    private fun page(): Response {
        val html = pageCache ?: ctx.assets.open("index.html").bufferedReader().use { it.readText() }.also { pageCache = it }
        return noCache(newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", html))
    }

    private fun ping(): Response {
        val r = noCache(newFixedLengthResponse(Status.OK, "text/plain", "ok"))
        r.addHeader("X-T", System.currentTimeMillis().toString())
        return r
    }

    /** 0 = right PIN, 1 = wrong PIN, 2 = locked for a while after too many wrong tries. */
    private fun checkPin(pin: String): Int {
        val now = System.currentTimeMillis()
        if (now < Hub.lockUntil) return 2
        if (Hub.pin.isEmpty() || pin != Hub.pin) {
            Hub.badPins++
            if (Hub.badPins >= 5) {
                Hub.badPins = 0
                Hub.lockUntil = now + 30_000
                Hub.logErr("Too many wrong PINs. Control is locked for 30 seconds.")
            }
            return 1
        }
        Hub.badPins = 0
        return 0
    }

    private fun sendFrame(f: Triple<ByteArray, Int, Long>, rot: Int = -1, mirror: Boolean = false): Response {
        val (bytes, seq, stamp) = f
        val r = newFixedLengthResponse(Status.OK, "image/jpeg", ByteArrayInputStream(bytes), bytes.size.toLong())
        r.addHeader("X-Seq", seq.toString())
        r.addHeader("X-T", stamp.toString())
        if (rot >= 0) {
            r.addHeader("X-Rot", rot.toString())
            r.addHeader("X-Mirror", if (mirror) "1" else "0")
        }
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    /** Waits for the next picture. 204 means nothing changed on the phone screen. */
    private fun frame(session: IHTTPSession): Response {
        val after = session.parameters["after"]?.firstOrNull()?.toIntOrNull() ?: -1
        val f = Frames.waitNewer(after, 700)
        if (f == null) {
            return noCache(newFixedLengthResponse(Status.NO_CONTENT, "text/plain", ""))
        }
        return sendFrame(f)
    }

    /** The phone camera, one picture at a time. Needs the PIN and the switch in the phone app. */
    private fun cam(session: IHTTPSession): Response {
        val bad = checkPin(session.parameters["pin"]?.firstOrNull() ?: "")
        if (bad != 0) return text(Status.FORBIDDEN, if (bad == 2) "locked" else "pin")
        if (!Hub.camAllowed) return text(Status.FORBIDDEN, "off")
        Hub.lastCamPoll = System.currentTimeMillis()
        val after = session.parameters["after"]?.firstOrNull()?.toIntOrNull() ?: -1
        val f = CamFrames.waitNewer(after, 700)
        if (f == null) {
            return noCache(newFixedLengthResponse(Status.NO_CONTENT, "text/plain", ""))
        }
        return sendFrame(f, Hub.camRot, Hub.camMirror)
    }

    private fun info(): JSONObject {
        val (bat, chg) = battery()
        val o = JSONObject()
            .put("w", Hub.frameW).put("h", Hub.frameH)
            .put("fps", Hub.fps).put("quality", Hub.quality).put("scale", Hub.scalePct)
            .put("preset", Hub.preset).put("health", Hub.showHealth)
            .put("sentFps", Hub.sentFps).put("encodeMs", Hub.encodeMs).put("kb", Hub.lastKb)
            .put("dropped", Hub.dropped).put("viewers", Hub.viewers)
            .put("t", System.currentTimeMillis())
            .put("bat", bat).put("chg", chg)
            .put("acc", Hub.accOn).put("ctl", Hub.controlOn).put("snd", Hub.soundOn)
            .put("alis", AudioPipe.count)
            .put("camAllowed", Hub.camAllowed).put("camOn", Hub.camOn).put("flash", Hub.camHasFlash)
            .put("torch", Hub.camTorch).put("camFront", Hub.camFront).put("camMsg", Hub.camMsg)
            .put("micAllowed", Hub.micAllowed).put("micLive", Hub.micLive)
            .put("vlock", Hub.viewLock).put("ring", Hub.ringing)
        try {
            o.put("dev", Build.MANUFACTURER + " " + Build.MODEL).put("andr", Build.VERSION.RELEASE)
            val sf = StatFs(Environment.getDataDirectory().path)
            o.put("stFree", sf.availableBytes).put("stTotal", sf.totalBytes)
            val mi = ActivityManager.MemoryInfo()
            ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
            o.put("ramFree", mi.availMem).put("ramTotal", mi.totalMem)
            o.put("up", SystemClock.elapsedRealtime())
        } catch (e: Exception) {
        }
        return o
    }

    private fun battery(): Pair<Int, Boolean> {
        return try {
            val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            (if (lvl < 0) -1 else lvl * 100 / sc) to chg
        } catch (e: Exception) {
            -1 to false
        }
    }

    /** Phone sound as a never-ending download of raw 48 kHz stereo 16-bit pieces. */
    private fun audio(): Response {
        val r = newChunkedResponse(Status.OK, "application/octet-stream", AudioStream(AudioPipe, 3840))
        r.addHeader("Cache-Control", "no-store")
        r.addHeader("X-Rate", "48000")
        return r
    }

    /** The phone microphone as a never-ending download of raw 48 kHz mono 16-bit pieces. */
    private fun mic(session: IHTTPSession): Response {
        val bad = checkPin(session.parameters["pin"]?.firstOrNull() ?: "")
        if (bad != 0) return text(Status.FORBIDDEN, if (bad == 2) "locked" else "pin")
        if (!Hub.micAllowed) return text(Status.FORBIDDEN, "off")
        val r = newChunkedResponse(Status.OK, "application/octet-stream", AudioStream(MicPipe, 1920))
        r.addHeader("Cache-Control", "no-store")
        r.addHeader("X-Rate", "48000")
        r.addHeader("X-Ch", "1")
        return r
    }

    private fun reply(status: Status, ok: Boolean, err: String = "", extra: JSONObject? = null): Response {
        val o = extra ?: JSONObject()
        o.put("ok", ok)
        if (err.isNotEmpty()) o.put("err", err)
        return noCache(newFixedLengthResponse(status, "application/json", o.toString()))
    }

    /** Everything the PC does to the phone: taps, keys, buttons, apps, camera. Needs the PIN every time. */
    private fun ctl(session: IHTTPSession): Response {
        if (session.method == Method.POST) session.parseBody(HashMap())
        val p = session.parameters
        fun s(k: String): String = p[k]?.firstOrNull() ?: ""
        fun f(k: String): Float = s(k).toFloatOrNull() ?: 0f
        val bad = checkPin(s("pin"))
        if (bad == 2) return reply(Status.FORBIDDEN, false, "locked")
        if (bad == 1) return reply(Status.FORBIDDEN, false, "pin")
        val a = s("a")
        val svc = WaveControl.inst
        if (a == "status") {
            return reply(
                Status.OK, true, "",
                JSONObject().put("acc", svc != null).put("control", Hub.controlOn).put("sound", Hub.soundOn)
                    .put("cam", Hub.camAllowed).put("mic", Hub.micAllowed)
            )
        }
        // camera and finder do not need the control switch
        when (a) {
            "camon" -> {
                if (!Hub.camAllowed) return reply(Status.OK, false, "camoff")
                val cs = CastService.inst ?: return reply(Status.OK, false, "nocast")
                val r = cs.camStart(s("front") == "1", s("q").toIntOrNull() ?: 1)
                return reply(Status.OK, r.isEmpty(), r)
            }
            "camoff" -> {
                CastService.inst?.camStop()
                return reply(Status.OK, true)
            }
            "torch" -> {
                if (!Hub.camAllowed) return reply(Status.OK, false, "camoff")
                Hub.camTorch = s("on") == "1"
                CastService.inst?.camApplyTorch()
                return reply(Status.OK, true)
            }
            "ring" -> {
                Finder.start(ctx)
                return reply(Status.OK, true)
            }
            "stopring" -> {
                Finder.stop(ctx)
                return reply(Status.OK, true)
            }
            "buzz" -> {
                Finder.buzz(ctx, longArrayOf(0, 800), -1)
                return reply(Status.OK, true)
            }
        }
        if (!Hub.controlOn) return reply(Status.OK, false, "off")
        when (a) {
            "vol" -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val d = when (s("d")) {
                    "up" -> AudioManager.ADJUST_RAISE
                    "down" -> AudioManager.ADJUST_LOWER
                    else -> AudioManager.ADJUST_TOGGLE_MUTE
                }
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI)
                return reply(Status.OK, true)
            }
            "wake" -> {
                val pm = ctx.getSystemService(PowerManager::class.java)
                @Suppress("DEPRECATION")
                val wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "wavecast:wake")
                wl.acquire(3000)
                return reply(Status.OK, true)
            }
            "apps" -> {
                val pm = ctx.packageManager
                val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val rows = list.map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                    .filter { it.second != ctx.packageName }
                    .sortedBy { it.first.lowercase() }
                val arr = JSONArray()
                for ((label, pkg) in rows) arr.put(JSONArray().put(label).put(pkg))
                return reply(Status.OK, true, "", JSONObject().put("apps", arr))
            }
            "notes" -> {
                val arr = JSONArray()
                for (n in Hub.notes.toList()) {
                    arr.put(JSONObject().put("app", n.app).put("title", n.title).put("text", n.text).put("t", n.time))
                }
                return reply(Status.OK, true, "", JSONObject().put("notes", arr).put("acc", svc != null))
            }
            "clearnotes" -> {
                Hub.notes.clear()
                return reply(Status.OK, true)
            }
        }
        if (svc == null) return reply(Status.OK, false, "acc")
        val ok = when (a) {
            "touch" -> svc.touch(s("id").toIntOrNull() ?: 0, s("k"), f("x"), f("y"))
            "release" -> { svc.releaseAll(); true }
            "tap" -> { svc.tap(f("x"), f("y"), s("hold").toLongOrNull() ?: 50L); true }
            "swipe" -> { svc.swipe(f("x1"), f("y1"), f("x2"), f("y2"), s("dur").toLongOrNull() ?: 200L); true }
            "pinch" -> { svc.pinch(f("x"), f("y"), s("d") == "1"); true }
            "back", "home", "recents", "notif", "quick", "power", "lock", "shot" -> svc.global(a)
            "type" -> svc.typeText(s("t"))
            "key" -> svc.key(s("k"))
            "launch" -> svc.launch(s("pkg"))
            "openurl" -> svc.openUrl(s("u"))
            else -> return reply(Status.BAD_REQUEST, false, "what")
        }
        return reply(Status.OK, ok, if (ok) "" else if (a == "type" || a == "key") "field" else "failed")
    }

    private fun cfg(session: IHTTPSession): Response {
        val p = session.parameters
        p["preset"]?.firstOrNull()?.toIntOrNull()?.let { Hub.applyPreset(it.coerceIn(0, 2)) }
        p["fps"]?.firstOrNull()?.toIntOrNull()?.let { Hub.fps = it.coerceIn(1, 60) }
        p["quality"]?.firstOrNull()?.toIntOrNull()?.let { Hub.quality = it.coerceIn(10, 100) }
        p["scale"]?.firstOrNull()?.toIntOrNull()?.let { Hub.scalePct = it.coerceIn(20, 100) }
        Hub.save()
        return json(info())
    }

    /** GET gives the phone's clipboard. POST puts the PC's text on the phone's clipboard. */
    private fun clip(session: IHTTPSession): Response {
        if (session.method == Method.POST) {
            session.parseBody(HashMap())
            val t = session.parameters["text"]?.firstOrNull() ?: ""
            Hub.pcClip = t
            Handler(Looper.getMainLooper()).post {
                try {
                    val cm = ctx.getSystemService(ClipboardManager::class.java)
                    cm.setPrimaryClip(ClipData.newPlainText("WaveCast", t))
                } catch (e: Exception) {
                    Hub.logErr("Clipboard: " + (e.message ?: ""))
                }
            }
            return text(Status.OK, "ok")
        }
        return json(JSONObject().put("seq", Hub.phoneClipSeq).put("text", Hub.phoneClip))
    }

    /** The PC page reports its own errors here, and reads the phone's log. */
    private fun log(session: IHTTPSession): Response {
        if (session.method == Method.POST) {
            session.parseBody(HashMap())
            val m = session.parameters["msg"]?.firstOrNull()
            if (!m.isNullOrBlank()) Hub.logErr("PC: " + m.take(200))
            return text(Status.OK, "ok")
        }
        val arr = JSONArray()
        for (e in Hub.errors.toList().take(30)) arr.put(e)
        return json(JSONObject().put("errors", arr))
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun upload(session: IHTTPSession): Response {
        val files = HashMap<String, String>()
        session.parseBody(files)
        val tmp = files["file"] ?: return text(Status.BAD_REQUEST, "No file")
        val raw = session.parameters["file"]?.firstOrNull() ?: "file"
        val name = raw.substringAfterLast('/').substringAfterLast('\\').ifBlank { "file" }
        val size = File(tmp).length()
        val saved = save(name, tmp)
        Hub.received.add(0, Got(name, size, System.currentTimeMillis(), saved))
        return text(Status.OK, "ok")
    }

    /** Puts the received file in Downloads/WaveCast. */
    private fun save(name: String, tmp: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/WaveCast")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Could not create the file")
        resolver.openOutputStream(uri)!!.use { out ->
            FileInputStream(tmp).use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        File(tmp).delete()
        return uri
    }
}
