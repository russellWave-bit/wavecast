package com.breadwinner.wavecast

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** A file the PC sent to the phone. */
data class Got(val name: String, val size: Long, val time: Long, val uri: Uri?)

/** A phone notification seen by the control service, shown on the PC page. */
data class Note(val app: String, val title: String, val text: String, val time: Long)

/** Shared state between the service, the web server and the screens. */
object Hub {
    private var sp: android.content.SharedPreferences? = null

    var running by mutableStateOf(false)
    /** 0 = my hotspot, 1 = auto hotspot (default), 2 = USB cable */
    var mode by mutableStateOf(1)
    var ssid by mutableStateOf("")
    var pass by mutableStateOf("")
    var hotspotMsg by mutableStateOf("")
    var port by mutableStateOf(8080)
    var viewers by mutableStateOf(0)

    // picture settings (the phone applies them live)
    var preset by mutableStateOf(1)      // 0 game, 1 normal, 2 music
    var fps by mutableStateOf(20)
    var quality by mutableStateOf(65)
    var scalePct by mutableStateOf(67)
    var showHealth by mutableStateOf(true)
    var stayAwake by mutableStateOf(true)

    // round 2: control, sound and the PIN
    var controlOn by mutableStateOf(true)
    var soundOn by mutableStateOf(true)
    var pin by mutableStateOf("")
    var accOn by mutableStateOf(false)
    var audioMsg by mutableStateOf("")
    var audioListeners by mutableStateOf(0)
    @Volatile var badPins = 0
    @Volatile var lockUntil = 0L
    val notes = mutableStateListOf<Note>()

    // round 3: camera, microphone, finder, privacy
    var camAllowed by mutableStateOf(false)
    var micAllowed by mutableStateOf(false)
    var viewLock by mutableStateOf(false)
    var camOn by mutableStateOf(false)
    var micLive by mutableStateOf(false)
    var camHasFlash by mutableStateOf(false)
    var camFront by mutableStateOf(false)
    var camTorch by mutableStateOf(false)
    var camMsg by mutableStateOf("")
    var ringing by mutableStateOf(false)
    var fingers by mutableStateOf(0)
    @Volatile var camRot = 0
    @Volatile var camMirror = false
    @Volatile var lastCamPoll = 0L

    // live numbers for the Health tab
    var sentFps by mutableStateOf(0)
    var encodeMs by mutableStateOf(0)
    var lastKb by mutableStateOf(0)
    var frameW by mutableStateOf(0)
    var frameH by mutableStateOf(0)
    @Volatile var dropped = 0
    var droppedShown by mutableStateOf(0)

    // clipboard
    var phoneClip by mutableStateOf("")
    @Volatile var phoneClipSeq = 0
    var pcClip by mutableStateOf("")

    val errors = mutableStateListOf<String>()
    val received = mutableStateListOf<Got>()
    private val seen = ConcurrentHashMap<String, Long>()

    fun init(c: Context) {
        val s = c.getSharedPreferences("wc", Context.MODE_PRIVATE)
        sp = s
        mode = s.getInt("mode", 1)
        preset = s.getInt("preset", 1)
        fps = s.getInt("fps", 20)
        quality = s.getInt("quality", 65)
        scalePct = s.getInt("scale", 67)
        showHealth = s.getBoolean("health", true)
        stayAwake = s.getBoolean("awake", true)
        controlOn = s.getBoolean("ctl", true)
        soundOn = s.getBoolean("snd", true)
        camAllowed = s.getBoolean("cam", false)
        micAllowed = s.getBoolean("mic", false)
        viewLock = s.getBoolean("vlock", false)
    }

    fun newPin() {
        pin = (1000 + java.security.SecureRandom().nextInt(9000)).toString()
        badPins = 0
        lockUntil = 0L
    }

    fun save() {
        sp?.edit()
            ?.putInt("mode", mode)?.putInt("preset", preset)?.putInt("fps", fps)
            ?.putInt("quality", quality)?.putInt("scale", scalePct)
            ?.putBoolean("health", showHealth)?.putBoolean("awake", stayAwake)
            ?.putBoolean("ctl", controlOn)?.putBoolean("snd", soundOn)
            ?.putBoolean("cam", camAllowed)?.putBoolean("mic", micAllowed)
            ?.putBoolean("vlock", viewLock)
            ?.apply()
    }

    /** Game keeps the delay low, Music keeps a steadier picture. */
    fun applyPreset(p: Int) {
        preset = p
        when (p) {
            0 -> { fps = 30; quality = 50; scalePct = 50 }
            2 -> { fps = 10; quality = 80; scalePct = 75 }
            else -> { fps = 20; quality = 65; scalePct = 67 }
        }
        save()
    }

    fun logErr(msg: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
        errors.add(0, "$t  $msg")
        while (errors.size > 60) errors.removeAt(errors.size - 1)
    }

    fun touch(ip: String) {
        seen[ip] = System.currentTimeMillis()
        recount()
    }

    fun recount() {
        val now = System.currentTimeMillis()
        viewers = seen.values.count { now - it < 6_000 }
    }

    fun clearSeen() {
        seen.clear()
        viewers = 0
    }
}

fun fmtSize(b: Long): String {
    if (b < 0) return "?"
    val d = b.toDouble()
    return when {
        d >= 1e9 -> String.format(Locale.US, "%.2f GB", d / 1e9)
        d >= 1e6 -> String.format(Locale.US, "%.1f MB", d / 1e6)
        d >= 1e3 -> String.format(Locale.US, "%.0f KB", d / 1e3)
        else -> "$b B"
    }
}

/** Finds the phone's address on the hotspot, USB cable or Wi-Fi. Returns (address, interface name). */
fun findIp(mode: Int): Pair<String, String>? {
    val found = ArrayList<Pair<String, String>>()
    try {
        val all = NetworkInterface.getNetworkInterfaces() ?: return null
        for (ni in all) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in ni.inetAddresses) {
                if (a is Inet4Address && a.isSiteLocalAddress) {
                    val host = a.hostAddress ?: continue
                    found.add(host to ni.name)
                }
            }
        }
    } catch (e: Exception) {
        return null
    }
    fun rank(n: String): Int {
        val usb = n.startsWith("rndis") || n.startsWith("usb") || n.startsWith("eth")
        val hot = n.startsWith("ap") || n.startsWith("swlan")
        val wifi = n.startsWith("wlan")
        return if (mode == 2) {
            when { usb -> 0; hot -> 1; wifi -> 2; else -> 3 }
        } else {
            when { hot -> 0; wifi -> 1; usb -> 2; else -> 3 }
        }
    }
    return found.minByOrNull { rank(it.second) }
}

/** A box holding the newest picture, waiting for the PC to fetch it. One for the screen, one for the camera. */
open class FrameBox {
    private val lock = Object()
    @Volatile var data: ByteArray? = null
    @Volatile var seq = 0
    @Volatile var stamp = 0L
    @Volatile var served = 0

    fun put(bytes: ByteArray) {
        synchronized(lock) {
            if (seq > 0 && served < seq) Hub.dropped++
            data = bytes
            stamp = System.currentTimeMillis()
            seq++
            lock.notifyAll()
        }
    }

    /** Waits up to [ms] for a picture newer than [after]. Null when nothing new came. */
    fun waitNewer(after: Int, ms: Long): Triple<ByteArray, Int, Long>? {
        synchronized(lock) {
            if (seq == after) {
                try { lock.wait(ms) } catch (e: InterruptedException) { }
            }
            val d = data
            if (seq == after || d == null) return null
            if (seq > served) served = seq
            return Triple(d, seq, stamp)
        }
    }

    fun reset() {
        synchronized(lock) {
            data = null
            seq = 0
            served = 0
            lock.notifyAll()
        }
    }
}

object Frames : FrameBox()
object CamFrames : FrameBox()

/** Sound waiting for PC pages. Each listening page gets its own small queue. */
open class Pipe {
    private val subs = java.util.concurrent.CopyOnWriteArrayList<java.util.concurrent.LinkedBlockingQueue<ByteArray>>()
    val count: Int get() = subs.size

    fun subscribe(): java.util.concurrent.LinkedBlockingQueue<ByteArray> {
        val q = java.util.concurrent.LinkedBlockingQueue<ByteArray>(100)
        subs.add(q)
        return q
    }

    fun unsubscribe(q: java.util.concurrent.LinkedBlockingQueue<ByteArray>) {
        subs.remove(q)
    }

    fun push(b: ByteArray) {
        for (q in subs) {
            if (!q.offer(b)) {
                q.poll()
                q.offer(b)
            }
        }
    }
}

/** The phone's own sound (what it is playing). */
object AudioPipe : Pipe()

/** The phone's microphone. */
object MicPipe : Pipe()

/** What the PC page downloads for sound: raw 16-bit pieces, one 20 ms piece at a time. */
class AudioStream(private val pipe: Pipe, chunk: Int) : java.io.InputStream() {
    private val q = pipe.subscribe()
    private var cur = ByteArray(0)
    private var pos = 0
    @Volatile private var closed = false
    private val silence = ByteArray(chunk)

    override fun read(): Int {
        val one = ByteArray(1)
        val n = read(one, 0, 1)
        return if (n <= 0) -1 else (one[0].toInt() and 0xFF)
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (closed) return -1
        if (pos >= cur.size) {
            val next = try { q.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { null }
            cur = next ?: silence
            pos = 0
        }
        val n = minOf(len, cur.size - pos)
        System.arraycopy(cur, pos, b, off, n)
        pos += n
        return n
    }

    override fun close() {
        closed = true
        pipe.unsubscribe(q)
    }
}
