package com.breadwinner.wavecast

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.content.Intent
import android.graphics.Path
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.ArrayDeque

/**
 * The hands of WaveCast. Android only lets an accessibility service tap, swipe and type for you,
 * so the PC's mouse and keyboard end up here. It does nothing until the PC has typed the right PIN.
 */
class WaveControl : AccessibilityService() {
    companion object {
        @Volatile var inst: WaveControl? = null
    }

    private val queue = ArrayDeque<GestureDescription>()
    private val lock = Object()
    private var busy = false
    private var busyAt = 0L
    private var pwBuf = ""

    /** One finger that is touching the phone right now, driven live by the PC. */
    private class Finger {
        var sent: GestureDescription.StrokeDescription? = null
        var pend: GestureDescription.StrokeDescription? = null
        var cx = 0f
        var cy = 0f
        var tx = 0f
        var ty = 0f
        var ending = false
        var builtEnding = false
        var last = System.currentTimeMillis()
    }

    private val fingers = LinkedHashMap<Int, Finger>()

    override fun onServiceConnected() {
        inst = this
        Hub.accOn = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        inst = null
        Hub.accOn = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        inst = null
        Hub.accOn = false
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        try {
            val pkg = e.packageName?.toString() ?: return
            if (pkg == packageName) return
            val n = e.parcelableData as? Notification
            val ex = n?.extras
            val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = ex?.getCharSequence(Notification.EXTRA_TEXT)?.toString()
                ?: e.text.joinToString(" ")
            if (title.isBlank() && text.isBlank()) return
            val label = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (x: Exception) {
                pkg
            }
            Hub.notes.add(0, Note(label, title, text, System.currentTimeMillis()))
            while (Hub.notes.size > 40) Hub.notes.removeAt(Hub.notes.size - 1)
        } catch (x: Exception) {
        }
    }

    // ---------- touch ----------

    private fun screen(): Pair<Int, Int> {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    private fun clampX(v: Float, w: Int) = (v * w).coerceIn(1f, (w - 2).toFloat())
    private fun clampY(v: Float, h: Int) = (v * h).coerceIn(1f, (h - 2).toFloat())

    fun tap(nx: Float, ny: Float, holdMs: Long) {
        val (w, h) = screen()
        val p = Path()
        p.moveTo(clampX(nx, w), clampY(ny, h))
        enqueue(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0L, holdMs.coerceIn(30L, 2500L))).build())
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durMs: Long) {
        val (w, h) = screen()
        val p = Path()
        p.moveTo(clampX(x1, w), clampY(y1, h))
        p.lineTo(clampX(x2, w), clampY(y2, h))
        enqueue(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0L, durMs.coerceIn(60L, 2500L))).build())
    }

    /** Two fingers: grow = true spreads them apart (zoom in), false pinches them together. */
    fun pinch(nx: Float, ny: Float, grow: Boolean) {
        val (w, h) = screen()
        val cx = clampX(nx, w)
        val cy = clampY(ny, h)
        val near = w * 0.05f
        val far = w * 0.22f
        val a = if (grow) near else far
        val b = if (grow) far else near
        val p1 = Path()
        p1.moveTo((cx - a).coerceIn(1f, (w - 2).toFloat()), cy)
        p1.lineTo((cx - b).coerceIn(1f, (w - 2).toFloat()), cy)
        val p2 = Path()
        p2.moveTo((cx + a).coerceIn(1f, (w - 2).toFloat()), cy)
        p2.lineTo((cx + b).coerceIn(1f, (w - 2).toFloat()), cy)
        enqueue(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p1, 0L, 260L))
            .addStroke(GestureDescription.StrokeDescription(p2, 0L, 260L)).build())
    }

    /**
     * Live touch. The PC says "finger 3 went down here", "finger 3 moved there", "finger 3 lifted".
     * Every few milliseconds all the fingers are sent to Android as one continuing gesture,
     * so a finger really follows the mouse, a game stick really holds, and buttons can be pressed together.
     */
    fun touch(id: Int, kind: String, nx: Float, ny: Float): Boolean {
        val (w, h) = screen()
        val x = clampX(nx, w)
        val y = clampY(ny, h)
        val now = System.currentTimeMillis()
        synchronized(lock) {
            val f = fingers[id]
            when (kind) {
                "down" -> {
                    if (f != null) {
                        f.tx = x
                        f.ty = y
                        f.ending = false
                        f.last = now
                    } else {
                        if (fingers.size >= 8) return false
                        val nf = Finger()
                        nf.cx = x
                        nf.cy = y
                        nf.tx = x
                        nf.ty = y
                        fingers[id] = nf
                    }
                }
                "move" -> {
                    if (f == null) return true
                    f.tx = x
                    f.ty = y
                    f.last = now
                }
                "up" -> {
                    if (f == null) return true
                    f.tx = x
                    f.ty = y
                    f.ending = true
                }
                else -> return false
            }
            Hub.fingers = fingers.size
        }
        pump()
        return true
    }

    fun releaseAll() {
        synchronized(lock) {
            for (f in fingers.values) f.ending = true
        }
        pump()
    }

    /** Builds the next piece of the gesture for every finger. Call with the lock held. */
    private fun buildSegment(): GestureDescription? {
        val now = System.currentTimeMillis()
        val b = GestureDescription.Builder()
        var n = 0
        for (f in fingers.values) {
            if (n >= 9) break
            if (!f.ending && now - f.last > 12000L) f.ending = true
            val p = Path()
            p.moveTo(f.cx, f.cy)
            val dx = f.tx - f.cx
            val dy = f.ty - f.cy
            val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            val moving = dist > 0.5f
            if (moving) p.lineTo(f.tx, f.ty)
            var dur = if (moving) (30f + dist / 10f).toLong().coerceIn(30L, 140L) else 60L
            val first = f.sent == null
            if (first && f.ending && !moving) dur = 45L
            val prev = f.sent
            val st = if (prev == null) {
                GestureDescription.StrokeDescription(p, 0L, dur, !f.ending)
            } else {
                prev.continueStroke(p, 0L, dur, !f.ending)
            }
            f.pend = st
            f.builtEnding = f.ending
            f.cx = f.tx
            f.cy = f.ty
            b.addStroke(st)
            n++
        }
        return if (n > 0) b.build() else null
    }

    /** One gesture at a time. Android cancels a running gesture when a new one starts. */
    private fun enqueue(g: GestureDescription) {
        synchronized(lock) {
            while (queue.size >= 6) queue.pollFirst()
            queue.addLast(g)
        }
        pump()
    }

    private fun pump() {
        var next: GestureDescription? = null
        var live = false
        synchronized(lock) {
            val now = System.currentTimeMillis()
            if (busy && now - busyAt > 4000L) busy = false
            if (busy) return
            if (fingers.isNotEmpty()) {
                next = buildSegment()
                live = true
            } else {
                next = queue.pollFirst()
            }
            if (next != null) {
                busy = true
                busyAt = now
            }
        }
        val g = next ?: return
        val isLive = live
        val cb = object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                synchronized(lock) {
                    busy = false
                    if (isLive) {
                        val it = fingers.values.iterator()
                        while (it.hasNext()) {
                            val f = it.next()
                            val ps = f.pend
                            if (ps != null) {
                                f.sent = ps
                                f.pend = null
                                if (f.builtEnding) it.remove()
                            }
                        }
                        Hub.fingers = fingers.size
                    }
                }
                pump()
            }

            override fun onCancelled(d: GestureDescription?) {
                synchronized(lock) {
                    busy = false
                    if (isLive) {
                        fingers.clear()
                        Hub.fingers = 0
                    }
                }
                pump()
            }
        }
        val ok = try { dispatchGesture(g, cb, null) } catch (e: Exception) { false }
        if (!ok) {
            synchronized(lock) {
                busy = false
                if (isLive) {
                    fingers.clear()
                    Hub.fingers = 0
                }
            }
            Hub.logErr("Android refused a tap or swipe")
        }
    }

    // ---------- buttons ----------

    fun global(name: String): Boolean {
        val a = when (name) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notif" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick" -> GLOBAL_ACTION_QUICK_SETTINGS
            "power" -> GLOBAL_ACTION_POWER_DIALOG
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN
            "shot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            else -> return false
        }
        return performGlobalAction(a)
    }

    fun openUrl(u: String): Boolean {
        var url = u.trim()
        if (url.isEmpty()) return false
        if (!url.contains("://")) url = "https://$url"
        if (!url.startsWith("http://") && !url.startsWith("https://")) return false
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            Hub.logErr("Could not open the link: " + (e.message ?: ""))
            false
        }
    }

    fun launch(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            startActivity(i)
            true
        } catch (e: Exception) {
            Hub.logErr("Could not open $pkg: " + (e.message ?: ""))
            false
        }
    }

    // ---------- typing ----------

    private fun field(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
    }

    /** Edits the text in the field that has the cursor. [op] gets (text, selStart, selEnd) and returns (newText, caret). */
    private fun edit(op: (String, Int, Int) -> Pair<String, Int>): Boolean {
        val n = field() ?: return false
        val hint = n.isShowingHintText
        var cur = if (hint) "" else (n.text?.toString() ?: "")
        if (n.isPassword) {
            if (cur.isEmpty()) pwBuf = ""
            if (pwBuf.length == cur.length) cur = pwBuf
        }
        var s = if (hint) 0 else n.textSelectionStart
        var e = if (hint) 0 else n.textSelectionEnd
        if (s < 0 || e < 0) {
            s = cur.length
            e = cur.length
        }
        if (s > e) {
            val x = s
            s = e
            e = x
        }
        s = s.coerceIn(0, cur.length)
        e = e.coerceIn(0, cur.length)
        val (next, caret) = op(cur, s, e)
        if (n.isPassword) pwBuf = next
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, next)
        val ok = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok) setCaret(n, caret, caret)
        return ok
    }

    private fun setCaret(n: AccessibilityNodeInfo, from: Int, to: Int): Boolean {
        val a = Bundle()
        a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, from)
        a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, to)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, a)
    }

    fun typeText(t: String): Boolean = edit { cur, s, e ->
        (cur.substring(0, s) + t + cur.substring(e)) to (s + t.length)
    }

    /** Keys: del, fdel, enter, left, right, home, end, selall, copy, cut, paste. */
    fun key(k: String): Boolean {
        when (k) {
            "del" -> return edit { cur, s, e ->
                if (s != e) (cur.substring(0, s) + cur.substring(e)) to s
                else if (s > 0) (cur.substring(0, s - 1) + cur.substring(s)) to (s - 1)
                else cur to s
            }
            "fdel" -> return edit { cur, s, e ->
                if (s != e) (cur.substring(0, s) + cur.substring(e)) to s
                else if (s < cur.length) (cur.substring(0, s) + cur.substring(s + 1)) to s
                else cur to s
            }
            "enter" -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    val n = field() ?: return false
                    return n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                }
                return typeText("\n")
            }
        }
        val n = field() ?: return false
        val len = n.text?.length ?: 0
        val s = n.textSelectionStart.coerceAtLeast(0)
        val e = n.textSelectionEnd.coerceAtLeast(0)
        return when (k) {
            "left" -> setCaret(n, if (s != e) minOf(s, e) else (s - 1).coerceAtLeast(0), if (s != e) minOf(s, e) else (s - 1).coerceAtLeast(0))
            "right" -> setCaret(n, if (s != e) maxOf(s, e) else (e + 1).coerceAtMost(len), if (s != e) maxOf(s, e) else (e + 1).coerceAtMost(len))
            "home" -> setCaret(n, 0, 0)
            "end" -> setCaret(n, len, len)
            "selall" -> setCaret(n, 0, len)
            "copy" -> n.performAction(AccessibilityNodeInfo.ACTION_COPY)
            "cut" -> n.performAction(AccessibilityNodeInfo.ACTION_CUT)
            "paste" -> n.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            else -> false
        }
    }
}
