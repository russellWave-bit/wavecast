package com.breadwinner.wavecast

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlin.math.sin
import kotlinx.coroutines.delay

// Glass: a calm, mostly white look. Frosted panes over a pale sky, and one blue accent.
val Bg = Color(0xFFF3F6FB)
val BgBot = Color(0xFFE3EAF6)
val Ink = Color(0xFF1F2937)
val CardC = Color(0xFFFFFFFF)
val Track = Color(0xFFD7DFEE)
val TextC = Ink
val Muted = Color(0xFF6B778C)
val Blue = Color(0xFF3B7BF6)
val Hair = Color(0x261F2937)
val Acc = Blue
val OnAcc = Color(0xFFFFFFFF)
val Danger = Color(0xFFE5484D)
// the old colourful names all mean the one accent now
val Sand = Blue
val Warm = Blue
val Pink = Blue
val Sky = Blue
val Violet = Blue
val WarnTxt = Color(0xFFB45309)
val Good = Color(0xFF22A06B)
val GoodTxt = Color(0xFF15803D)
// card tints are ignored: every card is the same frosted white
val Mint = Color(0xFFFFFFFF)
val Butter = Color(0xFFFFFFFF)
val Blush = Color(0xFFFFFFFF)

@Composable
fun T(text: String, size: Int = 13, color: Color = TextC, weight: FontWeight = FontWeight.SemiBold, modifier: Modifier = Modifier) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier)
}

/** The pale sky behind everything. */
fun Modifier.sky(): Modifier = this
    .background(Brush.verticalGradient(listOf(Bg, BgBot)))
    .drawBehind {
        drawCircle(
            Brush.radialGradient(listOf(Color(0x99C9D8FF), Color.Transparent), Offset(size.width * 0.1f, size.height * 0.05f), size.width * 0.9f),
            size.width * 0.9f, Offset(size.width * 0.1f, size.height * 0.05f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0x88D9ECFF), Color.Transparent), Offset(size.width * 0.95f, size.height * 0.95f), size.width),
            size.width, Offset(size.width * 0.95f, size.height * 0.95f)
        )
    }

/** A pane of frosted glass. */
@Composable
fun Card(modifier: Modifier = Modifier, tint: Color = CardC, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.fillMaxWidth()
            .shadow(10.dp, shape, ambientColor = Color(0x331F2960), spotColor = Color(0x331F2960))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xE6FFFFFF), Color(0xB8FFFFFF))))
            .border(1.dp, Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0x40FFFFFF))), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Pill(text: String, filled: Boolean = true, color: Color = Acc, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val textColor = if (filled) Color.White else Ink
    val base = if (filled) {
        Modifier.shadow(6.dp, shape, ambientColor = color.copy(alpha = 0.35f), spotColor = color.copy(alpha = 0.35f))
            .clip(shape).background(Brush.verticalGradient(listOf(color.copy(alpha = 0.92f), color)))
    } else {
        Modifier.clip(shape).background(Color(0xD9FFFFFF)).border(1.dp, Hair, shape)
    }
    Box(
        Modifier.padding(bottom = 3.dp).then(base)
            .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 14, textColor, FontWeight.SemiBold) }
}

@Composable
fun Chip(text: String, on: Boolean, color: Color = Good) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape).background(if (on) color else Color(0xB3FFFFFF))
            .border(1.dp, if (on) Color.Transparent else Hair, shape)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) { T(text, 11, if (on) Color.White else Muted, FontWeight.SemiBold) }
}

@Composable
fun Seg(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xB3FFFFFF)).border(1.dp, Hair, shape).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (i == sel) Blue else Color.Transparent).clickable { onSel(i) },
                contentAlignment = Alignment.Center
            ) { T(s, 12, if (i == sel) Color.White else Ink, FontWeight.SemiBold) }
        }
    }
}

@Composable
fun ToggleRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
        T(label, 14, modifier = Modifier.weight(1f))
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = Blue, checkedThumbColor = Color.White, checkedBorderColor = Blue,
                uncheckedTrackColor = Track, uncheckedThumbColor = Color.White, uncheckedBorderColor = Track
            )
        )
    }
}

@Composable
fun LabeledSlider(label: String, value: Int, range: IntRange, unit: String, onChange: (Int) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            T(label, 13, modifier = Modifier.weight(1f))
            T("$value$unit", 13, Blue, FontWeight.SemiBold)
        }
        Slider(
            value = value.toFloat(), onValueChange = { onChange(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue, inactiveTrackColor = Track)
        )
    }
}

@Composable
fun Qr(text: String, dp: Dp) {
    val m = remember(text) {
        try {
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, mapOf(EncodeHintType.MARGIN to 1))
        } catch (e: Exception) {
            null
        }
    }
    val shape = RoundedCornerShape(10.dp)
    Canvas(Modifier.size(dp).clip(shape).background(Color.White).border(1.dp, Hair, shape)) {
        if (m != null) {
            val cell = this.size.width / m.width
            for (y in 0 until m.height) {
                for (x in 0 until m.width) {
                    if (m.get(x, y)) drawRect(Ink, Offset(x * cell, y * cell), Size(cell + 0.6f, cell + 0.6f))
                }
            }
        }
    }
}

@Composable
fun rememberWaveTime(): State<Float> {
    val t = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) t.value += ((n - last) / 1e9f).coerceAtMost(0.05f) * (if (Hub.running) 2.6f else 0.9f)
                last = n
            }
        }
    }
    return t
}

/** A soft, pale band with slow white waves. */
@Composable
fun WaveBand(modifier: Modifier) {
    val t = rememberWaveTime()
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val dd = density
        drawRect(
            Brush.linearGradient(
                listOf(Color(0xFFD3E2FF), Color(0xFFE9F0FF), Color(0xFFF6F8FF)),
                Offset(0f, 0f), Offset(w, h)
            )
        )
        drawCircle(Color(0x66FFFFFF), 70f * dd, Offset(w * 0.86f, h * 0.2f))
        drawCircle(Color(0x44FFFFFF), 34f * dd, Offset(w * 0.12f, h * 0.35f))
        val wc = listOf(Color(0x55FFFFFF), Color(0x99FFFFFF), Bg)
        for (i in 0..2) {
            val path = Path()
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w) {
                val y = h * (0.58f + 0.12f * i) +
                    5f * dd * (0.8f + 0.3f * i) * sin(x / w * (1.4f + 0.5f * i) * 6.283f + t.value * (1.0f + 0.45f * i) + i * 2f)
                path.lineTo(x, y)
                x += 6f * dd
            }
            path.lineTo(w, h)
            path.close()
            drawPath(path, wc[i])
        }
    }
}

private val TABS = listOf("Cast", "Control", "Studio", "Speed", "Health", "Share", "Remote", "More")

@Composable
fun WaveCastApp(onStart: () -> Unit, onStop: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    val t = rememberWaveTime()
    var remote by remember { mutableStateOf<RTarget?>(null) }
    val rt = remote
    if (rt != null) {
        Box(Modifier.fillMaxSize().sky()) { RemoteScreen(rt) { remote = null } }
    } else {
    Column(Modifier.fillMaxSize().sky()) {
        Box(Modifier.fillMaxWidth()) {
            WaveBand(Modifier.matchParentSize())
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 42.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    T("WAVECAST 3", 11, Muted, FontWeight.SemiBold)
                    Text(TABS[tab], color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                }
                val live = Hub.running
                val pulse = if (live) 0.55f + 0.45f * sin(t.value * 3f) else 1f
                val chipShape = RoundedCornerShape(20.dp)
                Row(
                    Modifier.clip(chipShape).background(if (live) Good else Color(0xCCFFFFFF))
                        .border(1.dp, if (live) Color.Transparent else Hair, chipShape)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(if (live) Color.White.copy(alpha = pulse) else Muted))
                    Spacer(Modifier.width(6.dp))
                    T(if (live) "LIVE" else "OFF", 12, if (live) Color.White else Muted, FontWeight.SemiBold)
                }
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (tab) {
                0 -> CastTab(onStart, onStop)
                1 -> ControlTab()
                2 -> StudioTab()
                3 -> SpeedTab()
                4 -> HealthTab()
                5 -> ShareTab()
                6 -> RemoteTab { remote = it }
                else -> MoreTab()
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Color(0xE6FFFFFF))
                .drawBehind { drawRect(Hair, Offset(0f, 0f), Size(size.width, 1.dp.toPx())) }
                .navigationBarsPadding().padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            TABS.forEachIndexed { i, s ->
                val on = i == tab
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                        .background(if (on) Blue.copy(alpha = 0.14f) else Color.Transparent)
                        .clickable { tab = i }.padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) { T(s, 11, if (on) Blue else Muted, if (on) FontWeight.Bold else FontWeight.Medium) }
            }
        }
    }
    }
}

@Composable
fun CastTab(onStart: () -> Unit, onStop: () -> Unit) {
    val ctx = LocalContext.current
    var addr by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Hub.running, Hub.mode) {
        while (true) {
            addr = findIp(Hub.mode)?.first
            delay(2000)
        }
    }
    Card(tint = if (Hub.running) Mint else Butter) {
        T(if (Hub.running) "You're live!" else "Ready to cast", 22, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        T(
            if (Hub.running) "${Hub.viewers} PC watching" else "Tap Start, accept the Android popup, then open the address on your PC.",
            13, Muted, FontWeight.Medium
        )
        Spacer(Modifier.height(12.dp))
        if (Hub.running) Pill("Stop casting", true, Danger) { onStop() } else Pill("Start casting") { onStart() }
        if (Hub.hotspotMsg.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            T(Hub.hotspotMsg, 12, WarnTxt, FontWeight.Medium)
        }
        if (Hub.running) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("Screen", true, Acc)
                Chip("Sound", Hub.soundOn, Warm)
                Chip("Camera", Hub.camOn, Pink)
                Chip("Mic", Hub.micLive, Violet)
            }
        }
    }
    if (Hub.running) {
        val url = if (addr != null) "http://$addr:${Hub.port}" else null
        Card {
            T("Open this on your PC", 14)
            Spacer(Modifier.height(6.dp))
            T(url?.removePrefix("http://") ?: "Finding the address...", 26, Acc, FontWeight.Bold)
            T("Type it into Chrome or Edge. The PC must be on the same hotspot, Wi-Fi or USB cable.", 12, Muted, FontWeight.Medium)
            if (url != null) {
                Spacer(Modifier.height(12.dp))
                Qr(if (Hub.pin.isNotEmpty()) url + "/?pin=" + Hub.pin else url, 160.dp)
                Spacer(Modifier.height(6.dp))
                T("Scan this with WaveCast Remote to control this phone with no typing.", 12, Muted, FontWeight.Medium)
            }
        }
        if (Hub.mode == 1 && Hub.ssid.isNotEmpty()) {
            Card(tint = Blush) {
                T("Join this Wi-Fi on your PC first", 14)
                Spacer(Modifier.height(6.dp))
                T("Name: ${Hub.ssid}", 16, Ink, FontWeight.SemiBold)
                T("Password: ${Hub.pass}", 16, Ink, FontWeight.SemiBold)
            }
        }
    } else {
        Card {
            T("How should the PC connect?", 14)
            Spacer(Modifier.height(10.dp))
            Seg(listOf("My hotspot", "Auto hotspot", "USB cable"), Hub.mode) { Hub.mode = it; Hub.save() }
            Spacer(Modifier.height(8.dp))
            T(
                when (Hub.mode) {
                    0 -> "Turn on your phone's own hotspot, join it from the PC, then start."
                    1 -> "The app makes a private hotspot for you. It shows the name and password."
                    else -> "Plug the cable in and turn on USB tethering in the phone's settings."
                },
                12, Muted, FontWeight.Medium
            )
            if (Hub.mode != 1) {
                Spacer(Modifier.height(10.dp))
                Pill("Open hotspot settings", false) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }
}

@Composable
fun ControlTab() {
    val ctx = LocalContext.current
    Card(tint = Butter) {
        T("Control from the PC", 18, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        T("The PC can tap, swipe, drag, type and play games on this phone, with a mouse, keyboard or gamepad.", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        ToggleRow("Allow control from the PC", Hub.controlOn) { Hub.controlOn = it; Hub.save() }
    }
    Card {
        T("Step 1: switch on Accessibility", 14)
        Spacer(Modifier.height(6.dp))
        if (Hub.accOn) {
            T("Accessibility is ON. The PC can control this phone.", 13, GoodTxt, FontWeight.SemiBold)
        } else {
            T("Accessibility is OFF. Android makes you switch this on yourself, once.", 13, WarnTxt, FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            T("Open the button below, find WaveCast control (look under Installed apps or Downloaded apps), switch it on and tap Allow.", 12, Muted, FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Pill("Open Accessibility settings") {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            }
        }
    }
    Card(tint = Blush) {
        T("Step 2: type this PIN on the PC", 14)
        Spacer(Modifier.height(6.dp))
        if (Hub.running && Hub.pin.isNotEmpty()) {
            T(Hub.pin, 46, Acc, FontWeight.Bold)
            T("Open the Control tab on the PC page and type it in. Nobody can control the phone, or open the camera and mic, without it. A new PIN is made each time you start casting.", 12, Muted, FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Pill("Make a new PIN", false) { Hub.newPin() }
        } else {
            T("Start casting on the Cast tab to get a PIN.", 13, Muted, FontWeight.Medium)
        }
    }
    Card {
        T("Privacy", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        ToggleRow("Ask for the PIN before showing the screen", Hub.viewLock) { Hub.viewLock = it; Hub.save() }
        T("When this is on, anyone who opens the address sees a PIN box first. Good for shared Wi-Fi.", 12, Muted, FontWeight.Medium)
    }
    Card {
        T("Sound", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        ToggleRow("Send phone sound to the PC", Hub.soundOn) { Hub.soundOn = it; Hub.save() }
        T(
            if (Hub.running) "${Hub.audioListeners} PC listening" else "Sound starts when you start casting.",
            12, Muted, FontWeight.Medium
        )
        if (Hub.audioMsg.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            T(Hub.audioMsg, 12, WarnTxt, FontWeight.Medium)
        }
        Spacer(Modifier.height(6.dp))
        T("The phone keeps playing its own sound too, so turn the phone volume down if you only want the PC to play it. Some apps block sound capture.", 12, Muted, FontWeight.Medium)
    }
}

@Composable
fun StudioTab() {
    val ctx = LocalContext.current
    Card(tint = Blush) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Camera", 20, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Chip(if (Hub.camOn) "LIVE ON PC" else "OFF", Hub.camOn, Pink)
        }
        Spacer(Modifier.height(4.dp))
        ToggleRow("Let the PC use the camera", Hub.camAllowed) {
            Hub.camAllowed = it
            if (!it) CastService.inst?.camStop()
            Hub.save()
        }
        T("The PC needs the PIN, and the camera only runs while the PC is looking at it. It stops by itself a few seconds after the PC page closes.", 12, Muted, FontWeight.Medium)
        if (Hub.camMsg.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            T(Hub.camMsg, 12, WarnTxt, FontWeight.SemiBold)
        }
        if (Hub.camOn) {
            Spacer(Modifier.height(8.dp))
            T((if (Hub.camFront) "Front camera" else "Back camera") + (if (Hub.camTorch) ", torch on" else ""), 13, Ink, FontWeight.SemiBold)
        }
    }
    Card(tint = Mint) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Microphone", 20, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Chip(if (Hub.micLive) "LISTENING" else "OFF", Hub.micLive, Violet)
        }
        Spacer(Modifier.height(4.dp))
        ToggleRow("Let the PC hear the microphone", Hub.micAllowed) { Hub.micAllowed = it; Hub.save() }
        T("The PC hears what this phone's mic hears. Handy as a baby monitor or to listen in a room. It only records while a PC is listening.", 12, Muted, FontWeight.Medium)
    }
    Card(tint = Butter) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Find my phone", 20, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Chip(if (Hub.ringing) "RINGING" else "QUIET", Hub.ringing, Acc)
        }
        Spacer(Modifier.height(4.dp))
        T("From the PC page (Phone tab) you can make this phone ring loudly, even on silent, and buzz. Try it here first.", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Ring now", true, Danger) { Finder.start(ctx.applicationContext) }
            Pill("Stop", false) { Finder.stop(ctx.applicationContext) }
        }
    }
    Card {
        T("Fingers from the PC", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        T("Touches the PC is holding down right now: ${Hub.fingers}", 13, Ink, FontWeight.SemiBold)
        T("If a touch ever gets stuck, let go of everything.", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        Pill("Let go of everything", false) { WaveControl.inst?.releaseAll() }
    }
    Card(tint = Sky.copy(alpha = 0.18f)) {
        T("Play phone games from the PC", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        T("On the PC page open Play. Press a key or a gamepad button, then click where it should touch the phone screen. Sticks work too. Save the layout for each game.", 12, Muted, FontWeight.Medium)
    }
}

@Composable
fun SpeedTab() {
    Card(tint = Butter) {
        T("What are you doing?", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Seg(listOf("Game", "Normal", "Music"), Hub.preset) { Hub.applyPreset(it) }
        Spacer(Modifier.height(8.dp))
        T(
            when (Hub.preset) {
                0 -> "Low delay. Fewer details, but it keeps up with fast action."
                2 -> "Steadier and sharper. A little slower, which is fine for music and video."
                else -> "A good balance for everyday use."
            },
            12, Muted, FontWeight.Medium
        )
    }
    Card {
        T("Fine tune", 16, weight = FontWeight.Bold)
        LabeledSlider("Frames per second", Hub.fps, 5..30, "") { Hub.fps = it; Hub.save() }
        LabeledSlider("Picture quality", Hub.quality, 30..95, "%") { Hub.quality = it; Hub.save() }
        LabeledSlider("Picture size", Hub.scalePct, 30..100, "%") { Hub.scalePct = it; Hub.save() }
        T("The PC page also has a buffer slider and a Smart quality switch that lowers the quality by itself when the connection gets slow.", 12, Muted, FontWeight.Medium)
    }
}

@Composable
fun HealthTab() {
    Card {
        ToggleRow("Show latency and errors", Hub.showHealth) { Hub.showHealth = it; Hub.save() }
        T("Switch this off to keep this screen and the PC panel quiet.", 12, Muted, FontWeight.Medium)
    }
    if (Hub.showHealth) {
        Card(tint = Mint) {
            T("Right now", 16, weight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            StatRow("Frames sent per second", "${Hub.sentFps}")
            StatRow("Frames the PC missed", "${Hub.droppedShown}")
            StatRow("Time to make a picture", "${Hub.encodeMs} ms")
            StatRow("Picture size", "${Hub.lastKb} KB  (${Hub.frameW}x${Hub.frameH})")
            StatRow("PCs watching", "${Hub.viewers}")
            StatRow("Camera", if (Hub.camOn) "live" else "off")
            StatRow("Microphone", if (Hub.micLive) "live" else "off")
            StatRow("Fingers held by the PC", "${Hub.fingers}")
            Spacer(Modifier.height(6.dp))
            T("The PC page shows the full delay, because it can see how long pictures take to arrive.", 12, Muted, FontWeight.Medium)
        }
        Card {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                T("Errors", 16, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Pill("Clear", false) { Hub.errors.clear() }
            }
            Spacer(Modifier.height(8.dp))
            if (Hub.errors.isEmpty()) {
                T("No errors. Good.", 13, GoodTxt, FontWeight.SemiBold)
            } else {
                for (e in Hub.errors.take(25)) {
                    T(e, 12, WarnTxt, FontWeight.Medium, Modifier.padding(vertical = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        T(label, 13, Muted, FontWeight.Medium, Modifier.weight(1f))
        T(value, 13, Ink, FontWeight.SemiBold)
    }
}

@Composable
fun ShareTab() {
    val ctx = LocalContext.current
    Card(tint = Butter) {
        T("Clipboard", 18, weight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        T("Copy something on the phone, then come back here. The PC page picks it up. Text copied on the PC lands on the phone's clipboard.", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        T("Phone clipboard", 12, Muted)
        T(Hub.phoneClip.ifEmpty { "Nothing yet" }.take(160), 14, Ink, FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        T("Last text from the PC", 12, Muted)
        T(Hub.pcClip.ifEmpty { "Nothing yet" }.take(160), 14, Ink, FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Pill("Read phone clipboard now", false) { (ctx as? MainActivity)?.readClip() }
    }
    Card {
        T("Files from your PC", 18, weight = FontWeight.Bold)
        T("Drop files on the PC page. They are saved in Downloads/WaveCast.", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        if (Hub.received.isEmpty()) {
            T("Nothing received yet.", 13, Muted, FontWeight.Medium)
        } else {
            for (g in Hub.received.take(20)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    T(g.name, 13, modifier = Modifier.weight(1f))
                    T(fmtSize(g.size), 13, Muted)
                }
            }
        }
    }
}

@Composable
fun MoreTab() {
    Card {
        ToggleRow("Keep the phone screen awake while casting", Hub.stayAwake) { Hub.stayAwake = it; Hub.save() }
        T("Applies the next time you start casting.", 12, Muted, FontWeight.Medium)
    }
    Card(tint = Butter) {
        T("What's new in 3.0", 18, weight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        for (line in listOf(
            "Loud, bright new look on the phone and the PC page (3 colour themes)",
            "Live finger-drag: the phone finger follows your mouse",
            "Play phone games with a keyboard or gamepad (Play tab)",
            "Phone camera on the PC: front, back, torch, snapshots, recording",
            "Phone microphone on the PC",
            "Find my phone: ring loudly and buzz from the PC",
            "Phone dashboard: battery, storage, memory",
            "Pen and laser pointer on the screen view, snapshot gallery",
            "Smart quality, PIN lock for the screen, open a link on the phone"
        )) {
            T("• $line", 13, Ink, FontWeight.Medium, Modifier.padding(vertical = 2.dp))
        }
    }
    Card(tint = Mint) {
        T("Unlock gamepad and PC extras (one time)", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        T("Chrome and Edge only allow gamepads on a safe address. Tell the PC browser to trust this phone:", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("1. In the PC browser address bar type: chrome://flags/#unsafely-treat-insecure-origin-as-secure", 12, Ink, FontWeight.Medium)
        T("2. Type the phone address (http://...) in the box, set it to Enabled.", 12, Ink, FontWeight.Medium)
        T("3. Press Relaunch. The PC page also shows these steps with copy buttons.", 12, Ink, FontWeight.Medium)
    }
    Card {
        T("Tips", 16, weight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        T("Android shows a popup every time you start casting. That is a safety rule and no app can skip it.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("If casting stops by itself, set the app's battery use to Unrestricted in Android settings.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        T("Pictures may not show for apps that block screen capture, like some banking apps.", 13, Muted, FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        T("WaveCast 3.0", 12, Muted, FontWeight.Medium)
    }
}
